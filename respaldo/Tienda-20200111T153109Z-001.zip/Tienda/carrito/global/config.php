<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
define("KEY","develoteca");
define("COD","AES-128-ECB");
define("SERVIDOR","localhost");
define("USUARIO","root");
define("PASSWORD","");
define("BD","tienda");
define("DESCARGASPERMITIDAS","1");

//SANDBOX
//define("LINKAPI","https://api.sandbox.paypal.com");
//define("CLIENTID","ATqyN18EASUI5r6GAL09Sw7Y80JzHFga2yHHYwyPfjelXSCazVDdjghjFufKMYxUPLDAwclNkCJsWSmr");
//define("SECRET","EAEwiHiDac6f9Xil_AwQX8OmR5bFawQn5ENx7NSeQidOL4kwLc_9F4hjq2pgA2LEq5utQjUi");


//LIVE
define("LINKAPI","https://api.paypal.com");
define("CLIENTID","AfxnH_0czsV4a2QrSMBqUjhAsVK1SPg1Jax15cP18r24k9YjZqgH5yIi6Kb8cjUxa6-WGbb3UJ8DdIOr");
define("SECRET","EAIqqD9CBmi5g-378emCOquZ87LP2u4ZEm0qVa_68YY1j98vhCQpHXTBqx_lXWPezS92l9DOHcd-c8us");

?>